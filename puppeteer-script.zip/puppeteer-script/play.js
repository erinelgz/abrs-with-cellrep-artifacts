const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({
    headless: true,
    args: [
      '--autoplay-policy=no-user-gesture-required',
      '--disable-gpu'
    ]
  });

  const page = await browser.newPage();

  // 1. Go to login page
  await page.goto('http://10.0.16.2:8080/accounts/login/?next=/player/', { waitUntil: 'networkidle2' });

  // 2. Fill in login form
  await page.type('input[name="username"]', 'ertestin');
  await page.type('input[name="password"]', 'erin');

  // 3. Tick the checkbox (required by Puffer)
  await page.click('input[type="checkbox"]');

  // 4. Submit form
  await Promise.all([
    page.click('button[type="submit"]'),
    page.waitForNavigation({ waitUntil: 'networkidle2' })
  ]);

  // 5. You're now on /player/ — wait to stream
  console.log("✅ Logged in, watching video on /player/");
  await new Promise(resolve => setTimeout(resolve, 600000));  // Wait 60 seconds

  await browser.close();
})();
